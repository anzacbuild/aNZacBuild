plugin.video.rt
================
Kodi Addon for Russia Today News

3.0.8 added first aired date, remove external dep to lib removed from github
3.0.7 added screenshots and pipe to add multiple devs as recommended
3.0.6 regex updates, upstep and adjust youtube call, adjust arab live url, add banner, adjust fanart
3.0.5 minor website change
3.0.4 added YT playback
3.0.3 added French feed
3.0.2 added Spanish and Arab live feeds that I forgot
3.0.1 clean up and fix live feeds
2.0.2 website chnages
2.0.1 Isengard version - fixed live streams
